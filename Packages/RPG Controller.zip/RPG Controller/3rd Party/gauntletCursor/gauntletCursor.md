https://opengameart.org/content/gauntlet-cursor
